
class Node:
    def __init__(self, coordinates, parent = None):
        self.co = coordinates
        self.parent = parent
